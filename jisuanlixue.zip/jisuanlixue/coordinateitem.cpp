#include "coordinateitem.h"
#include <QPainter>
#include <QFont>

CoordinateItem::CoordinateItem(QPointF origin, qreal axisLength, QGraphicsItem *parent)
    : QGraphicsItem(parent),
      m_origin(origin),
      m_axisLength(axisLength)
{
}

QRectF CoordinateItem::boundingRect() const
{
    return QRectF(m_origin.x() - m_axisLength, m_origin.y() - m_axisLength, 2 * m_axisLength, 2 * m_axisLength);
}

void CoordinateItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->setRenderHint(QPainter::Antialiasing);

    QPen pen(Qt::black, 2);
    painter->setPen(pen);

    // 绘制x轴
    painter->drawLine(m_origin, QPointF(m_origin.x() + m_axisLength, m_origin.y()));

    // 绘制y轴
    painter->drawLine(m_origin, QPointF(m_origin.x(), m_origin.y() + m_axisLength));

    // 绘制箭头
    qreal arrowSize = 5.0;
    QPointF xArrowP1 = QPointF(m_origin.x() + m_axisLength - arrowSize, m_origin.y() - arrowSize);
    QPointF xArrowP2 = QPointF(m_origin.x() + m_axisLength - arrowSize, m_origin.y() + arrowSize);
    QPointF yArrowP1 = QPointF(m_origin.x() - arrowSize, m_origin.y() + m_axisLength - arrowSize);
    QPointF yArrowP2 = QPointF(m_origin.x() + arrowSize, m_origin.y() + m_axisLength - arrowSize);

    painter->drawLine(QPointF(m_origin.x() + m_axisLength, m_origin.y()), xArrowP1);
    painter->drawLine(QPointF(m_origin.x() + m_axisLength, m_origin.y()), xArrowP2);
    painter->drawLine(QPointF(m_origin.x(), m_origin.y() + m_axisLength), yArrowP1);
    painter->drawLine(QPointF(m_origin.x(), m_origin.y() + m_axisLength), yArrowP2);

    // 标注x和y
    QFont font = painter->font();
    font.setPointSize(12);
    painter->setFont(font);

    QPointF xLabelPos = QPointF(m_origin.x() + m_axisLength - 15, m_origin.y() + 15);
    QPointF yLabelPos = QPointF(m_origin.x() - 20, m_origin.y() + m_axisLength + 5);

    painter->drawText(xLabelPos, "x");
    painter->drawText(yLabelPos, "y");
}
