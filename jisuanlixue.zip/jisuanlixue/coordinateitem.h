
#ifndef COORDINATEITEM_H
#define COORDINATEITEM_H

#include <QGraphicsItem>

class CoordinateItem : public QGraphicsItem
{
public:
    CoordinateItem();
    explicit CoordinateItem(QPointF origin, qreal axisLength, QGraphicsItem *parent = nullptr); //C++ explicit,隐式转换,nullptr,override
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;

private:
    qreal m_width;
    qreal m_height;
    QPointF m_origin;
    qreal m_axisLength;
};

#endif // COORDINATEITEM_H
