#include "customarrowitem.h"
#include <QGraphicsScene>
#include <QToolTip>
#include <QGraphicsSceneMouseEvent>
#include <QCoreApplication>


CustomArrowItem::CustomArrowItem(qreal x, qreal y, qreal length, int a, int b, QGraphicsItem *parent)
    : QObject(), QGraphicsPathItem(parent) //C++ ...:QObject()?
{
    setAcceptHoverEvents(true);

    QPainterPath path;
    qreal arrowHeadSize = 10;

    // 竖直线
    if(b==1){
    path.moveTo(x, y);
    path.lineTo(x, y + length);
    // 箭头
    if(a==1){              //向下
    path.moveTo(x - arrowHeadSize / 2, y + length - arrowHeadSize);
    path.lineTo(x, y + length);
    path.lineTo(x + arrowHeadSize / 2, y + length - arrowHeadSize);
    setPath(path);}
    if(a==0){              //向上
    path.moveTo(x - arrowHeadSize / 2, y + arrowHeadSize);
    path.lineTo(x, y);
    path.lineTo(x + arrowHeadSize / 2, y + arrowHeadSize);
    setPath(path);}}
    if(b==0){
    path.moveTo(x, y);
    path.lineTo(x, y - length);
    // 箭头
    if(a==1){              //向上
    path.moveTo(x - arrowHeadSize / 2, y - length + arrowHeadSize);
    path.lineTo(x, y - length);
    path.lineTo(x + arrowHeadSize / 2, y - length + arrowHeadSize);
    setPath(path);}
    if(a==0){              //向下
    path.moveTo(x - arrowHeadSize / 2, y - arrowHeadSize);
    path.lineTo(x, y);
    path.lineTo(x + arrowHeadSize / 2, y - arrowHeadSize);
    setPath(path);}}

    // 水平线
    if(b==2){
    path.moveTo(x, y);
    path.lineTo(x-length, y);
    // 箭头
    if(a==1){              //向右
    path.moveTo(x - arrowHeadSize, y - arrowHeadSize/2);
    path.lineTo(x, y);
    path.lineTo(x - arrowHeadSize, y + arrowHeadSize/2);
    setPath(path);}
    if(a==0){              //向左
        path.moveTo(x-length + arrowHeadSize, y - arrowHeadSize/2);
        path.lineTo(x-length, y);
        path.lineTo(x-length + arrowHeadSize, y + arrowHeadSize/2);
    setPath(path);}}
    if(b==3){
    path.moveTo(x, y);
    path.lineTo(x+length, y);
    // 箭头
    if(a==1){              //向左
        path.moveTo(x + arrowHeadSize, y - arrowHeadSize/2);
        path.lineTo(x, y);
        path.lineTo(x + arrowHeadSize, y + arrowHeadSize/2);
    setPath(path);}
    if(a==0){              //向右
        path.moveTo(x+length - arrowHeadSize, y - arrowHeadSize/2);
        path.lineTo(x+length, y);
        path.lineTo(x+length - arrowHeadSize, y + arrowHeadSize/2);
    setPath(path);}}


}

void CustomArrowItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
         emit arrowClicked(); //qt不懂
    }
}

void CustomArrowItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    {QToolTip::showText(event->screenPos(), QCoreApplication::translate("CustomArrowItem", "点击删除"));}
}

void CustomArrowItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    QToolTip::hideText();
}
