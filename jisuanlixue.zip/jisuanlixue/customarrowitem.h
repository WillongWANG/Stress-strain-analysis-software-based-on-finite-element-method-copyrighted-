#ifndef CUSTOMARROWITEM_H
#define CUSTOMARROWITEM_H

#include <QGraphicsPathItem>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSceneHoverEvent>
#include <QToolTip>


class CustomArrowItem : public QObject,public QGraphicsPathItem //C++两个基类
{
    Q_OBJECT
    Q_INTERFACES(QGraphicsItem)                                 //qt语法不懂

public:
    CustomArrowItem(qreal x, qreal y, qreal length,int a, int b, QGraphicsItem *parent = nullptr);

    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;

signals: //不懂
    void arrowClicked();

private:
    int c;


};

#endif // CUSTOMARROWITEM_H
