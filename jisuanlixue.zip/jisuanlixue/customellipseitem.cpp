#include "customellipseitem.h"
#include <QGraphicsScene>
#include <QToolTip>
#include <QGraphicsSceneMouseEvent>
#include <QCoreApplication>
#include "mainwindow.h"

CustomEllipseItem::CustomEllipseItem(qreal x, qreal y, qreal width, qreal height, const yuankong &info, MainWindow *mainWindow, QGraphicsItem *parent)
    : QGraphicsEllipseItem(x, y, width, height, parent), _info(info), _mainWindow(mainWindow)
{
    setAcceptHoverEvents(true);
}

void CustomEllipseItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
        if (event->button() == Qt::LeftButton) {
            setFocus();

            // 在移除前，找到对应的结构体
            if (_mainWindow) {
                for (int i = 0; i < _mainWindow->yuankongList.size(); ++i) {
                    if (_mainWindow->yuankongList[i].x_2 == _info.x_2 &&
                        _mainWindow->yuankongList[i].y_2 == _info.y_2 &&
                        _mainWindow->yuankongList[i].banjin == _info.banjin) {
                        _mainWindow->yuankongList.removeAt(i);
                        QString myString = "删除圆孔x、y、半径分别为%1、%2、%3";
                        QString formattedString = myString.arg(_info.x_2).arg(_info.y_2).arg(_info.banjin);
                        _mainWindow->appendToTextBrowser(formattedString);
                        break;
                    }
                }
            }
        scene()->removeItem(this);
        delete this;
    }
}

void CustomEllipseItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    {QToolTip::showText(event->screenPos(), QCoreApplication::translate("CustomEllipseItem", "点击删除"));}
}

void CustomEllipseItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    QToolTip::hideText();
}
