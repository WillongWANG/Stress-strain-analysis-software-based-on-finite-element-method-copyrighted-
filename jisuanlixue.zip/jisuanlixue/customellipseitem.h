#pragma once
#ifndef CUSTOMELLIPSEITEM_H
#define CUSTOMELLIPSEITEM_H

#include <QGraphicsEllipseItem>
#include <QGraphicsSceneMouseEvent>
#include <QToolTip>
#include "mainwindow.h"

class CustomEllipseItem : public QGraphicsEllipseItem
{
public:
    CustomEllipseItem(qreal x, qreal y, qreal width, qreal height,const yuankong &info, MainWindow *mainWindow, QGraphicsItem *parent = nullptr);

protected: //C++ protected
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;

private:
    yuankong _info;
    MainWindow *_mainWindow;
    int c;
};

#endif // CUSTOMELLIPSEITEM_H
