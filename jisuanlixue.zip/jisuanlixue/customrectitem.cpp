#include "customrectitem.h"
#include <QGraphicsScene>
#include <QToolTip>
#include <QGraphicsSceneMouseEvent>
#include <QCoreApplication>

CustomRectItem::CustomRectItem(qreal x, qreal y, qreal width, qreal height, QGraphicsItem *parent)
    : QGraphicsRectItem(x, y, width, height, parent)
{
    setAcceptHoverEvents(true);
}

void CustomRectItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        setFocus(); }

        scene()->removeItem(this);
        delete this;

}

void CustomRectItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    {QToolTip::showText(event->screenPos(), QCoreApplication::translate("CustomRectItem", "点击删除"));}
}

void CustomRectItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    QToolTip::hideText();
}
