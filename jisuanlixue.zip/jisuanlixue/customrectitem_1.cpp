#include "customrectitem_1.h"
#include <QGraphicsScene>
#include <QToolTip>
#include <QGraphicsSceneMouseEvent>
#include <QCoreApplication>
#include "mainwindow.h"

CustomRectItem_1::CustomRectItem_1(qreal x, qreal y, qreal width, qreal height, const juxinkong &info, MainWindow *mainWindow, QGraphicsItem *parent)
    : QGraphicsRectItem(x, y, width, height, parent), _info(info), _mainWindow(mainWindow)
{
    setAcceptHoverEvents(true);
}

void CustomRectItem_1::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        setFocus();

        // 在移除前，找到对应的结构体
        if (_mainWindow) {
            for (int i = 0; i < _mainWindow->juxinkongList.size(); ++i) {
                if (_mainWindow->juxinkongList[i].x_5 == _info.x_5 &&
                    _mainWindow->juxinkongList[i].y_5 == _info.y_5 &&
                    _mainWindow->juxinkongList[i].chang_3 == _info.chang_3 &&
                    _mainWindow->juxinkongList[i].kuan_3 == _info.kuan_3) {
                    _mainWindow->juxinkongList.removeAt(i);
                    QString myString = "删除矩形孔x、y、长、宽分别为%1、%2、%3、%4";
                    QString formattedString = myString.arg(_info.x_5).arg(_info.y_5).arg(_info.chang_3).arg(_info.kuan_3);
                    _mainWindow->appendToTextBrowser(formattedString);
                    break;
                }
            }
        }

        scene()->removeItem(this);
        delete this;
    }
}

void CustomRectItem_1::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    QToolTip::showText(event->screenPos(), QCoreApplication::translate("CustomRectItem", "点击删除"));
}

void CustomRectItem_1::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    QToolTip::hideText();
}
