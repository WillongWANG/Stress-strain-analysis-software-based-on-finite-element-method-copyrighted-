#pragma once
#ifndef CUSTOMRECTITEM_1_H
#define CUSTOMRECTITEM_1_H

#include <QGraphicsRectItem>
#include <QGraphicsSceneMouseEvent>
#include <QToolTip>
#include "mainwindow.h"

class MainWindow;

class CustomRectItem_1 : public QGraphicsRectItem
{
public:
    CustomRectItem_1(qreal x, qreal y, qreal width, qreal height, const juxinkong &info, MainWindow *mainWindow, QGraphicsItem *parent = nullptr);


protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;

private:
    juxinkong _info;
    MainWindow *_mainWindow;
};

#endif // CUSTOMRECTITEM_1_H
